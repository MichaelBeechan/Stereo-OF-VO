Please download "Demo software: SIFT Keypoint Detector" from David Lowe's website

and place its files in the same folder, for example:

/SIFT
	/sift.m
	/match.m
 	/appendimages.m
...

then replace "match.m"  

David Lowe's website: http://www.cs.ubc.ca/~lowe/keypoints/

