Please download "raw data development kit" from Andreas Geiger's website

and place its files in the same folder, for example:

/devkit
	/convertOxtsToPose.m
	/loadOxtsliteData.m
 	/loadCalibration.m
... 

Andreas Geiger's website: http://www.cvlibs.net/datasets/kitti/raw_data.php
